package ejercicios

fun main() {
    val n:Int? = null
    println(n?.let { "Su numero es : " + n })
}