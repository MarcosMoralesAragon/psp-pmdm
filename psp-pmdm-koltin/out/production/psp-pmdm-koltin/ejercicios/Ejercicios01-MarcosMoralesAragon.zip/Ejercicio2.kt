package ejercicios

fun main() {
    val h = 12.3;
    val d = 3.0;

    val volumen = 3.1416 * (d/2) * (d/2) * h

    println("El volumen de su cilindro es $volumen")
}