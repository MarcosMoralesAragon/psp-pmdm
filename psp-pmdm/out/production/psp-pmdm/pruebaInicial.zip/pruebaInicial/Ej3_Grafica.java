package pruebaInicial;

import java.util.Scanner;

public class Ej3_Grafica {
    public static void main(String[] args) {

        int[] cantidadDeRepeticiones = new int[10];

        Scanner in = new Scanner(System.in);
        int numeroPorTeclado = 0;
        do{
            System.out.println("Introduce los numeros");
            numeroPorTeclado = in.nextInt();
            if(numeroPorTeclado > -1){
                cantidadDeRepeticiones[numeroPorTeclado] = cantidadDeRepeticiones[numeroPorTeclado] + 1;
            }
        }while (numeroPorTeclado > -1);

        for ( int i = 10; i > 0 ; i--){
            for (int y = 0; y < 10; y++){
                if (cantidadDeRepeticiones[y] == i){
                    cantidadDeRepeticiones[y] = cantidadDeRepeticiones[y] - 1;
                    System.out.print("* ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.println("");
        }
        System.out.println("0 1 2 3 4 5 6 7 8 9");
    }
}
